Problem statement is defined in the file "Bungee Coding Round.docx". Please refer to this file. 
